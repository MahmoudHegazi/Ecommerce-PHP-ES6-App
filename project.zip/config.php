<?php
$dbname = 'cost_app';
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = 'root';
